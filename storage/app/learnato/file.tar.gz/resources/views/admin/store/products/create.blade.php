@extends('admin.layouts.app')

@push('styles_top')

<link rel="stylesheet" href="/assets/default/vendors/sweetalert2/dist/sweetalert2.min.css">
<link rel="stylesheet" href="/assets/default/vendors/select2/select2.min.css">
<link rel="stylesheet" href="/assets/default/vendors/bootstrap-tagsinput/bootstrap-tagsinput.min.css">
<link rel="stylesheet" href="/assets/vendors/summernote/summernote-bs4.min.css">


<link rel="stylesheet" href="/assets/admin/vendor/persian-date/persian-date.min.css">
@endpush

@section('content')
<section class="section">
    <div class="section-header">
        <h1>{{ $pageTitle }}</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="/admin/">{{trans('admin/main.dashboard')}}</a>
            </div>
            <div class="breadcrumb-item">{{ $pageTitle}}</div>
        </div>
    </div>

    <div class="section-body">

        <div class="row">
            <div class="col-12 ">
                <div class="card">
                    <div class="card-body">

                        <form id="productForm" method="post"
                            action="/admin/store/products/{{ !empty($product) ? $product->id.'/update' : 'store' }}"
                            class="webinar-form">
                            {{ csrf_field() }}

                            @include('admin.store.products.create.basic_information')

                            @if(!empty($product))
                            @include('admin.store.products.create.extra_information' , ['product' => $product ])
                            @include('admin.store.products.create.image_and_files' , ['product' => $product ])
                            @include('admin.store.products.create.category_and_specification' , ['product' => $product
                            ])

                            <section class="mt-3">
                                <h2 class="section-title after-line">{{ trans('public.message_to_reviewer') }}</h2>

                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group mt-15">
                                            <textarea name="message_for_reviewer" rows="10"
                                                class="form-control"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            @endif

                            @if (!empty($product))
                            <div class="row">
                                <div class="col-12">
                                    <input type="hidden" id="productStatusInput" name="status" value="draft">

                                    <button type="button" id="saveAndPublish" class="btn btn-success">{{
                                        trans('admin/main.save_and_publish') }}</button>

                                    <button type="button" id="saveReject" class="btn btn-warning">{{
                                        trans('admin/main.reject') }}</button>

                                    <button class="btn btn-danger trigger--fire-modal-4"
                                        data-confirm="Are you sure? | Do you want to continue?"
                                        data-confirm-href="/admin/store/products/6/delete" data-confirm-text-yes="Yes"
                                        data-confirm-text-cancel="Cancel">
                                        {{ trans('admin/main.delete') }}
                                    </button>
                                </div>
                            </div>
                            @else
                            <div class="row">
                                <div class="col-12">
                                    <input type="hidden" id="productStatusInput" name="status" value="draft">

                                    <button type="button" id="saveAndPublish" class="btn btn-success">{{
                                        trans('admin/main.save_and_continue') }}</button>

                                </div>
                            </div>
                            @endif



                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('admin.store.products.create.modals.file_description_modal')
    @include('admin.store.products.create.modals.file_modal')
</section>
@endsection

@push('scripts_bottom')

<script>
    var saveSuccessLang = '{{ trans('webinars.success_store') }}';
    var requestFailedLang = '{{ trans('public.request_failed') }}';
    var maxFourImageCanSelect = '{{ trans('update.max_four_image_can_select') }}';
</script>

<script src="/assets/default/vendors/sweetalert2/dist/sweetalert2.min.js"></script>
<script src="/assets/default/vendors/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
<script src="/assets/vendors/summernote/summernote-bs4.min.js"></script>

<script src="/assets/default/js/admin/new_product.min.js"></script>

<script src="/assets/admin/vendor/persian-date/persian-date.min.js"></script>

<script>
    jalaliDatepicker.startWatch({
        time: "true",
        autoReadOnlyInput: "dynamic",
        zIndex: "9999"
});
</script>

@endpush