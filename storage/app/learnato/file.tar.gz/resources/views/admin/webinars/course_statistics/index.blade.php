@extends('admin.layouts.app')


@push('libraries_top')
<link rel="stylesheet" href="/assets/default/vendors/chartjs/chart.min.css" />
@endpush

@section('content')
<section class="section">
    <div class="section-header">
        <h1>{{ $pageTitle }}</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="/admin/">{{trans('admin/main.dashboard')}}</a>
            </div>
            <div class="breadcrumb-item">{{ $pageTitle}}</div>
        </div>
    </div>

    <div class="section-body">
        <section>
            <h2 class="section-title">{{ $webinar->title }}</h2>

            <div class="activities-container mt-3 p-3 p-lg-3">
                <div class="row">
                    <div class="col-6 col-md-3 d-flex align-items-center justify-content-center">
                        <div class="d-flex flex-column align-items-center text-center">
                            <img src="/assets/default/img/activity/48.svg" width="64" height="64" alt="">
                            <strong class="font-30 font-weight-bold text-dark mt-1">{{ $studentsCount }}</strong>
                            <span class="font-16 text-gray font-weight-500">{{ trans('admin/main.students') }}</span>
                        </div>
                    </div>

                    <div class="col-6 col-md-3 d-flex align-items-center justify-content-center">
                        <div class="d-flex flex-column align-items-center text-center">
                            <img src="/assets/default/img/activity/125.svg" width="64" height="64" alt="">
                            <strong class="font-30 font-weight-bold text-dark mt-1">{{ $commentsCount }}</strong>
                            <span class="font-16 text-gray font-weight-500">{{ trans('admin/main.comments') }}</span>
                        </div>
                    </div>

                    <div class="col-6 col-md-3 d-flex align-items-center justify-content-center">
                        <div class="d-flex flex-column align-items-center text-center">
                            <img src="/assets/default/img/activity/sales.svg" width="64" height="64" alt="">
                            <strong class="font-30 font-weight-bold text-dark mt-1">{{ $salesCount }}</strong>
                            <span class="font-16 text-gray font-weight-500">{{ trans('admin/main.sales') }}</span>
                        </div>
                    </div>

                    <div class="col-6 col-md-3 d-flex align-items-center justify-content-center">
                        <div class="d-flex flex-column align-items-center text-center">
                            <img src="/assets/default/img/activity/33.png" width="64" height="64" alt="">
                            <strong class="font-30 font-weight-bold text-dark mt-1">{{
                                addCurrencyToPrice(handlePriceFormat($salesAmount)) }}</strong>
                            <span class="font-16 text-gray font-weight-500">{{ trans('panel.sales_amount') }}</span>
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <section class="row">

            <div class="col-6 col-md-3 mt-3">
                <div class="dashboard-stats rounded-sm panel-shadow p-10 p-md-3 d-flex align-items-center">
                    <div class="stat-icon stat-icon-chapters">
                        <img src="/assets/default/img/icons/course-statistics/1.svg" alt="">
                    </div>
                    <div class="d-flex flex-column ml-2">
                        <span class="font-30 font-weight-bold text-dark">{{ $chaptersCount }}</span>
                        <span class="font-16 text-gray font-weight-500">{{ trans('admin/main.sections') }}</span>
                    </div>
                </div>
            </div>

            <div class="col-6 col-md-3 mt-3">
                <div class="dashboard-stats rounded-sm panel-shadow p-10 p-md-3 d-flex align-items-center">
                    <div class="stat-icon stat-icon-sessions">
                        <img src="/assets/default/img/icons/course-statistics/2.svg" alt="">
                    </div>
                    <div class="d-flex flex-column ml-2">
                        <span class="font-30 font-weight-bold text-dark">{{ $sessionsCount }}</span>
                        <span class="font-16 text-gray font-weight-500">{{ trans('public.sessions') }}</span>
                    </div>
                </div>
            </div>

            <div class="col-6 col-md-3 mt-3">
                <div class="dashboard-stats rounded-sm panel-shadow p-10 p-md-3 d-flex align-items-center">
                    <div class="stat-icon stat-icon-pending-quizzes">
                        <img src="/assets/default/img/icons/course-statistics/3.svg" alt="">
                    </div>
                    <div class="d-flex flex-column ml-2">
                        <span class="font-30 font-weight-bold text-dark">{{ $pendingQuizzesCount }}</span>
                        <span class="font-16 text-gray font-weight-500">{{ trans('update.pending_quizzes') }}</span>
                    </div>
                </div>
            </div>

            <div class="col-6 col-md-3 mt-3">
                <div class="dashboard-stats rounded-sm panel-shadow p-10 p-md-3 d-flex align-items-center">
                    <div class="stat-icon stat-icon-pending-assignments">
                        <img src="/assets/default/img/icons/course-statistics/4.svg" alt="">
                    </div>
                    <div class="d-flex flex-column ml-2">
                        <span class="font-30 font-weight-bold text-dark">{{ $pendingAssignmentsCount }}</span>
                        <span class="font-16 text-gray font-weight-500">{{ trans('update.pending_assignments') }}</span>
                    </div>
                </div>
            </div>

        </section>

        <section>
            <div class="row">
                <div class="col-12 col-md-3 mt-3">
                    <div class="course-statistic-cards-shadow py-3 px-2 py-md-3 px-md-3 rounded-sm bg-white">
                        <div class="d-flex align-items-center flex-column">
                            <img src="/assets/default/img/activity/33.png" width="64" height="64" alt="">

                            <span class="font-30 text-dark mt-3 font-weight-bold">{{ $courseRate }}</span>
                            <div class="stars-card d-flex align-items-center mt-2">
                                @php
                                $i = 5;
                                @endphp
                                @while(--$i >= 5 - $courseRate)
                                <i class="fa fa-star active"></i>
                                @endwhile
                                @while($i-- >= 0)
                                <i class="fa fa-star"></i>
                                @endwhile

                            </div>
                        </div>

                        <div
                            class="d-flex align-items-center justify-content-between mt-3 pt-3 border-top font-16 font-weight-500">
                            <span class="text-gray">{{ trans('update.total_rates') }}</span>
                            <span class="text-dark font-weight-bold">{{ $courseRateCount }}</span>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-md-3 mt-3">
                    <div class="course-statistic-cards-shadow py-3 px-2 py-md-3 px-md-3 rounded-sm bg-white">
                        <div class="d-flex align-items-center flex-column">
                            <img src="/assets/default/img/activity/88.svg" width="64" height="64" alt="">

                            <span class="font-30 text-dark mt-3 font-weight-bold">{{ $webinar->quizzes->count()
                                }}</span>
                            <span class="mt-2 font-16 font-weight-500 text-gray">{{ trans('admin/main.quizzes') }}</span>
                        </div>

                        <div
                            class="d-flex align-items-center justify-content-between mt-3 pt-3 border-top font-16 font-weight-500">
                            <span class="text-gray">{{ trans('quiz.average_grade') }}</span>
                            <span class="text-dark font-weight-bold">{{ $quizzesAverageGrade }}</span>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-md-3 mt-3">
                    <div class="course-statistic-cards-shadow py-3 px-2 py-md-3 px-md-3 rounded-sm bg-white">
                        <div class="d-flex align-items-center flex-column">
                            <img src="/assets/default/img/activity/homework.svg" width="64" height="64" alt="">

                            <span class="font-30 text-dark mt-3 font-weight-bold">{{ $webinar->assignments->count()
                                }}</span>
                            <span class="mt-2 font-16 font-weight-500 text-gray">{{ trans('update.assignments') }}</span>
                        </div>

                        <div
                            class="d-flex align-items-center justify-content-between mt-3 pt-3 border-top font-16 font-weight-500">
                            <span class="text-gray">{{ trans('quiz.average_grade') }}</span>
                            <span class="text-dark font-weight-bold">{{ $assignmentsAverageGrade }}</span>
                        </div>
                    </div>
                </div>

                {{-- <div class="col-12 col-md-3 mt-3">
                    <div class="course-statistic-cards-shadow py-3 px-2 py-md-3 px-md-3 rounded-sm bg-white">
                        <div class="d-flex align-items-center flex-column">
                            <img src="/assets/default/img/activity/39.svg" width="64" height="64" alt="">

                            <span class="font-30 text-dark mt-3 font-weight-bold">7</span>
                            <span class="mt-2 font-16 font-weight-500 text-gray">Forum Messages</span>
                        </div>

                        <div
                            class="d-flex align-items-center justify-content-between mt-3 pt-3 border-top font-16 font-weight-500">
                            <span class="text-gray">Active Forum Students</span>
                            <span class="text-dark font-weight-bold">5</span>
                        </div>
                    </div>
                </div> --}}
            </div>
        </section>

        <section>
            <div class="row">
                @include('admin.webinars.course_statistics.includes.pie_charts' ,[
                'cardTitle' => trans('update.students_user_roles'),
                'cardId' => 'studentsUserRolesChart',
                'cardPrimaryLabel' => $studentsUserRolesChart['labels'][0],
                'cardSecondaryLabel' => $studentsUserRolesChart['labels'][1],
                'cardWarningLabel' => $studentsUserRolesChart['labels'][2],
                ])

                @include('admin.webinars.course_statistics.includes.pie_charts' ,[
                'cardTitle' => trans('update.course_progress'),
                'cardId' => 'courseProgressChart',
                'cardPrimaryLabel' => $courseProgressChart['labels'][0],
                'cardSecondaryLabel' => $courseProgressChart['labels'][1],
                'cardWarningLabel' => $courseProgressChart['labels'][2],
                ])

                @include('admin.webinars.course_statistics.includes.pie_charts' ,[
                'cardTitle' => trans('quiz.quiz_status'),
                'cardId' => 'quizStatusChart',
                'cardPrimaryLabel' => $quizStatusChart['labels'][0],
                'cardSecondaryLabel' => $quizStatusChart['labels'][1],
                'cardWarningLabel' => $quizStatusChart['labels'][2],
                ])

                @include('admin.webinars.course_statistics.includes.pie_charts' ,[
                'cardTitle' => trans('update.assignments_status'),
                'cardId' => 'assignmentsStatusChart',
                'cardPrimaryLabel' => $assignmentsStatusChart['labels'][0],
                'cardSecondaryLabel' => $assignmentsStatusChart['labels'][1],
                'cardWarningLabel' => $assignmentsStatusChart['labels'][2],
                ])

            </div>
        </section>


        <section>
            <div class="row">
                <div class="col-12 col-md-6 mt-3">
                    <div class="course-statistic-cards-shadow monthly-sales-card pt-2 px-2 pb-3 rounded-sm bg-white">
                        <div class="d-flex align-items-center justify-content-between">
                            <h3 class="font-16 text-dark font-weight-bold">{{ trans('panel.monthly_sales') }}</h3>

                            {{-- <span class="font-16 font-weight-500 text-gray">Aug 2022</span> --}}
                        </div>

                        <div class="monthly-sales-chart mt-2">
                            <canvas id="monthlySalesChart" width="767" height="383"></canvas>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-md-6 mt-3">
                    <div class="course-statistic-cards-shadow monthly-sales-card pt-2 px-2 pb-3 rounded-sm bg-white">
                        <div class="d-flex align-items-center justify-content-between">
                            <h3 class="font-16 text-dark font-weight-bold">{{ trans('update.course_progress') }} (%)
                            </h3>
                        </div>

                        <div class="monthly-sales-chart mt-2">

                            <canvas id="courseProgressLineChart" width="767" height="383"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="mt-5">
            <h2 class="section-title">{{ trans('panel.students_list') }}</h2>

            <div class="panel-section-card py-3 px-3 mt-3">
                <div class="row">
                    <div class="col-12 ">
                        <div class="table-responsive">
                            <table class="table custom-table text-center ">
                                <thead>
                                    <tr>
                                        <th class="text-left text-gray">{{ trans('admin/main.student') }}</th>
                                        <th class="text-center text-gray">{{ trans('update.progress') }}</th>
                                        <th class="text-center text-gray">{{ trans('update.passed_quizzes') }}</th>
                                        <th class="text-center text-gray">{{ trans('update.unsent_assignments') }}</th>
                                        <th class="text-center text-gray">{{ trans('update.pending_assignments') }}</th>
                                        <th class="text-center text-gray">{{ trans('panel.purchase_date') }}</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    @foreach ($students as $item)
                                    <tr>
                                        <td class="text-left">
                                            <div class="user-inline-avatar d-flex align-items-center">
                                                <div class="avatar bg-gray200">
                                                    <img src="{{ $item->avatar }}" class="img-cover"
                                                        alt="">
                                                </div>
                                                <div class=" ml-2">
                                                    <span class="d-block text-dark font-weight-500">{{ $item->full_name }}</span>
                                            

                                                    @if($item->mobile)
                                                        <div class="mt-1 d-block font-12 text-gray">{{ $item->mobile }}</div>
                                                    @endif

                                                    @if($item->email)
                                                        <div class="d-block font-12 text-gray">{{ $item->email }}</div>
                                                    @endif
                                                </div>
                                            </div>
                                        </td>
                                        <td class="align-middle">
                                            <span class="text-dark font-weight-500">{{  $item->course_progress }}%</span>
                                        </td>
                                        <td class="align-middle">
                                            <span class="text-dark font-weight-500">{{ $item->passed_quizzes }}</span>
                                        </td>
                                        <td class="align-middle">
                                            <span class="text-dark font-weight-500">{{ $item->unsent_assignments }}</span>
                                        </td>
                                        <td class="align-middle">
                                            <span class="text-dark font-weight-500">{{ $item->pending_assignments }}</span>
                                        </td>
                                        <td class="align-middle">
                                            <span class="text-dark font-weight-500">{{ vertaFormat($item->created_at, '%d %B، %Y H:i') }}</span>
                                        </td>
                                    </tr>
                                    @endforeach


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="my-3">

            </div>

        </section>
    </div>
</section>





@endsection

@push('scripts_bottom')
<script src="/assets/default/vendors/chartjs/chart.min.js"></script>
<script src="/assets/default/js/panel/course_statistics.min.js"></script>

<script>
    (function ($) {
        "use strict";

        @if(!empty($studentsUserRolesChart))
        makePieChart('studentsUserRolesChart', @json($studentsUserRolesChart['labels']), @json($studentsUserRolesChart['data']));
        @endif

        @if(!empty($courseProgressChart))
        makePieChart('courseProgressChart', @json($courseProgressChart['labels']), @json($courseProgressChart['data']));
        @endif

        @if(!empty($quizStatusChart))
        makePieChart('quizStatusChart', @json($quizStatusChart['labels']), @json($quizStatusChart['data']));
        @endif

        @if(!empty($assignmentsStatusChart))
        makePieChart('assignmentsStatusChart', @json($assignmentsStatusChart['labels']), @json($assignmentsStatusChart['data']));
        @endif
            
        @if(!empty($monthlySalesChart))
        handleMonthlySalesChart(@json($monthlySalesChart['labels']),@json($monthlySalesChart['data']));
        @endif

                 
        @if(!empty($courseProgressLineChart))
        handleCourseProgressChart(@json($courseProgressLineChart['labels']),@json($courseProgressLineChart['data']));
        @endif

  
    })(jQuery)
</script>

@endpush