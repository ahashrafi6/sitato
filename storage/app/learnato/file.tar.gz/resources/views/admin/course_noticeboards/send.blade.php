@extends('admin.layouts.app')

@push('styles_top')
<link rel="stylesheet" href="/assets/vendors/summernote/summernote-bs4.min.css">
@endpush

@section('content')
<section class="section">
    <div class="section-header">
        <h1>{{ $pageTitle }}</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="/admin/">{{trans('admin/main.dashboard')}}</a>
            </div>
            <div class="breadcrumb-item">{{ $pageTitle }}</div>
        </div>
    </div>

    <div class="section-body">
        <div class="card">
            <div class="card-body">

                <form method="post"
                    action="/admin/course-noticeboards/{{ !empty($noticeboard) ? $noticeboard->id .'/update' : 'store' }}"
                    class="form-horizontal form-bordered mt-4">
                    {{ csrf_field() }}

                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label class="control-label" for="inputDefault">{!! trans('admin/main.title')
                                    !!}</label>
                                <input type="text" name="title"
                                    class="form-control @error('title') is-invalid @enderror"
                                    value="{{ !empty($noticeboard) ? $noticeboard->title : old('title') }}">
                                <div class="invalid-feedback">@error('title') {{ $message }} @enderror</div>
                            </div>

                            <div class="form-group">
                                <label class="input-label control-label">{{ trans('admin/main.course') }}</label>
                                <select name="webinar_id"
                                    class="form-control search-webinar-select2 select2-hidden-accessible">
                                    @if (!empty($noticeboard))
                                        <option value="{{ $noticeboard->webinar_id }}">{{ $noticeboard->webinar->title }}</option>
                                    @endif

                                </select>
                            </div>


                            <div class="form-group">
                                <label class="input-label control-label">{{ trans('update.color') }}</label>
                                <select name="color" id="colorSelect" class="form-control ">
                                    <option value="">انتخاب رنگ</option>

                                    <option value="warning" {{ !empty($noticeboard) ? ($noticeboard->color == 'warning'
                                        ? 'selected' : '') : '' }}>{{ trans('update.course_noticeboard_color_warning')
                                        }}</option>
                                    <option value="danger" {{ !empty($noticeboard) ? ($noticeboard->color == 'danger' ?
                                        'selected' : '') : '' }}>{{ trans('update.course_noticeboard_color_danger') }}
                                    </option>
                                    <option value="neutral" {{ !empty($noticeboard) ? ($noticeboard->color == 'neutral'
                                        ? 'selected' : '') : '' }}>{{ trans('update.course_noticeboard_color_neutral')
                                        }}</option>
                                    <option value="info" {{ !empty($noticeboard) ? ($noticeboard->color == 'info' ?
                                        'selected' : '') : '' }}>{{ trans('update.course_noticeboard_color_info') }}
                                    </option>
                                    <option value="success" {{ !empty($noticeboard) ? ($noticeboard->color == 'success'
                                        ? 'selected' : '') : '' }}>{{ trans('update.course_noticeboard_color_success')
                                        }}</option>
                                </select>
                                <div class="invalid-feedback"></div>
                            </div>

                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label">{{ trans('admin/main.message') }}</label>
                        <textarea name="message"
                            class="summernote form-control text-left  @error('message') is-invalid @enderror">{{ (!empty($noticeboard)) ? $noticeboard->message :'' }}</textarea>
                        <div class="invalid-feedback">@error('message') {{ $message }} @enderror</div>
                    </div>


                    <div class="form-group">
                        <div>
                            <button class="btn btn-primary" type="submit">{{ trans('admin/main.send_noticeboard')
                                }}</button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
</section>
@endsection

@push('scripts_bottom')
<script src="/assets/vendors/summernote/summernote-bs4.min.js"></script>
@endpush