@extends('admin.layouts.app')

@push('libraries_top')
<link rel="stylesheet" href="/assets/admin/vendor/persian-date/persian-date.min.css">
@endpush

@section('content')
<section class="section">
    <div class="section-header">
        <h1>{{ $pageTitle }}</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="/admin/">{{trans('admin/main.dashboard')}}</a>
            </div>
            <div class="breadcrumb-item">{{ $pageTitle }}</div>
        </div>
    </div>


    <div class="section-body">

        <section class="card">
            <div class="card-body">
                <form class="mb-0">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="input-label">{{trans('admin/main.search')}}</label>
                                <input type="text" class="form-control" name="search"
                                    value="{{ request()->get('search') }}">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="input-label">{{trans('admin/main.start_date')}}</label>
                                <div class="input-group">
                                    {{-- <input type="date" id="fsdate" class="text-center form-control" name="from"
                                        value="{{ request()->get('from') }}" placeholder="Start Date"> --}}
                                    <input data-jdp data-jdp-only-date class="form-control" name="from"
                                        value="{{ request()->get('from') }}">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="input-label">{{trans('admin/main.end_date')}}</label>
                                <div class="input-group">
                                    {{-- <input type="date" id="lsdate" class="text-center form-control" name="to"
                                        value="{{ request()->get('to') }}" placeholder="End Date"> --}}
                                    <input data-jdp data-jdp-only-date class="form-control" name="to"
                                        value="{{ request()->get('to') }}">
                                </div>
                            </div>
                        </div>


                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="input-label">{{ trans('admin/main.sender') }}</label>

                                <select name="sender_id" data-search-option="just_organization_and_teacher_role"
                                    class="form-control search-user-select2 select2-hidden-accessible"
                                    data-placeholder="Search user">

                                </select>
                            </div>
                        </div>


                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="input-label">{{trans('admin/main.types')}}</label>
                                <select name="color" data-plugin-selectTwo class="form-control populate">
                                    <option value="">{{trans('admin/main.all_types')}}</option>

                                    @foreach(\App\Models\CourseNoticeboard::$colors as $type)
                                    <option value="{{ $type }}" @if(request()->get('color') == $type) selected @endif>{{
                                        trans('update.course_noticeboard_color_'.$type) }}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>


                        <div class="col-md-4">
                            <div class="form-group mt-1">
                                <label class="input-label mb-4"> </label>
                                <input type="submit" class="text-center btn btn-primary w-100"
                                    value="{{trans('admin/main.show_results')}}">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </section>

        <div class="card">
            <div class="card-header">
                @can('admin_noticeboards_send')
                <div class="text-right">
                    <a href="/admin/noticeboards/send"
                        class="btn btn-primary">{{trans('admin/main.send_noticeboard')}}</a>
                </div>
                @endcan
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped font-14" id="datatable-basic">

                        <tr>
                            <th class="text-left">{{ trans('admin/main.title') }}</th>
                            <th class="text-center">{{ trans('admin/main.course') }}</th>
                            <th class="text-center">{{ trans('notification.sender') }}</th>
                            <th class="text-center">{{ trans('site.message') }}</th>
                            <th class="text-center">{{ trans('update.color') }}</th>
                            <th class="text-center">{{ trans('admin/main.created_at') }}</th>
                            <th>{{ trans('admin/main.actions') }}</th>
                        </tr>

                        @foreach($noticeboards as $noticeboard)
                        <tr>
                            <td class="text-left">{{ $noticeboard->title }}</td>
                            <td class="text-left">{{ $noticeboard->webinar->title }}</td>
                            <td class="text-center">{{ $noticeboard->creator->full_name }}</td>

                            <td class="text-center">
                                <button type="button" data-item-id="{{ $noticeboard->id }}"
                                    class="js-show-description btn btn-outline-primary">{{ trans('admin/main.show')
                                    }}</button>
                                <input type="hidden" value="{{ nl2br($noticeboard->message) }}">
                            </td>
                            <td class="text-center">{{ trans('update.course_noticeboard_color_'.$noticeboard->color) }}
                            </td>

                            <td class="text-center">{{ vertaFormat($noticeboard->created_at,'%d %B، %Y') }}</td>

                            <td width="100">
                                @can('admin_noticeboards_edit')
                                <a href="/admin/course-noticeboards/{{ $noticeboard->id }}/edit"
                                    class="btn-transparent  text-primary" data-toggle="tooltip" data-placement="top"
                                    title="{{ trans('admin/main.edit') }}">
                                    <i class="fa fa-edit"></i>
                                </a>
                                @endcan

                                @can('admin_notifications_delete')
                                @include('admin.includes.delete_button',['url' => '/admin/course-noticeboards/'.
                                $noticeboard->id.'/delete','btnClass' => ''])
                                @endcan
                            </td>
                        </tr>
                        @endforeach

                    </table>
                </div>
            </div>

            <div class="card-footer text-center">
                {{ $noticeboards->appends(request()->input())->links() }}
            </div>
        </div>
    </div>
</section>

<!-- Modal -->
<div class="modal fade" id="notificationMessageModal" tabindex="-1" aria-labelledby="notificationMessageLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="notificationMessageLabel">{{ trans('admin/main.contacts_message') }}</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">{{ trans('admin/main.close')
                    }}</button>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts_bottom')
<script src="/assets/default/js/admin/noticeboards.min.js"></script>

<script src="/assets/admin/vendor/persian-date/persian-date.min.js"></script>

<script>
    jalaliDatepicker.startWatch({
        time: "true",
        autoReadOnlyInput: "dynamic",
        zIndex: "9999"
});
</script>
@endpush