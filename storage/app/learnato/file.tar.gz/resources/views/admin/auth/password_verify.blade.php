@extends('web.default.layouts.email')

@section('body')
    <!-- content -->
    <td valign="top" class="bodyContent" mc:edit="body_content">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">ایمیل خود را تایید کنید</div>
                        <div class="card-body">
                            <div class="alert alert-success" role="alert">
                                لینک تایید به ایمیل شما ارسال شده است
                            </div>
                            <a href="{{ url('/admin/reset-password/'.$token.'?email='.$email) }}">کلیک کنید</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </td>
@endsection
