@extends('admin.layouts.app')


@push('libraries_top')
<link rel="stylesheet" href="/assets/admin/vendor/persian-date/persian-date.min.css">
@endpush


@section('content')
<section class="section">
    <div class="section-header">
        <h1>{{ $pageTitle }}</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="/admin/">{{trans('admin/main.dashboard')}}</a>
            </div>
            <div class="breadcrumb-item">{{ $pageTitle}}</div>
        </div>
    </div>

    <div class="section-body">


        <section class="card">
            <div class="card-body">
                <form method="get" class="mb-0">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="input-label">{{ trans('admin/main.search') }}</label>
                                <input type="text" class="form-control" name="item_title" value="">
                            </div>
                        </div>


                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="input-label">{{ trans('admin/main.start_date') }}</label>
                                <div class="input-group">
                        {{--             <input type="date" id="fsdate" class="text-center form-control" name="from" value=""
                                        placeholder="Start Date"> --}}

                                        <input data-jdp data-jdp-only-date class="form-control" name="from" value="{{ request()->get('from') }}">

                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="input-label">{{ trans('admin/main.end_date') }}</label>
                                <div class="input-group">
                              {{--       <input type="date" id="lsdate" class="text-center form-control" name="to" value=""
                                        placeholder="End Date"> --}}

                                        <input data-jdp data-jdp-only-date class="form-control" name="to" value="{{ request()->get('to') }}">
                                </div>
                            </div>
                        </div>


                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="input-label">{{ trans('admin/main.status') }}</label>
                                <select name="status" data-plugin-selecttwo="" class="form-control populate">
                                    <option value="">{{ trans('admin/main.all_status') }}</option>
                                    <option value="success">{{ trans('admin/main.success') }}</option>
                                    <option value="refund">{{ trans('admin/main.refund') }}</option>
                                    <option value="blocked">{{ trans('update.access_blocked') }}</option>
                                </select>
                            </div>
                        </div>


                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="input-label">{{ trans('admin/main.course') }}</label>

                                <select name="webinar_ids[]" multiple="multiple" data-search-option="just_teacher_role"
                                    class="form-control search-webinar-select2" data-placeholder="Search classes">

                                    @if(!empty($webinars) and $webinars->count() > 0)
                                    @foreach($webinars as $webinar)
                                    <option value="{{ $webinar->id }}" selected>{{ $webinar->title }}</option>
                                    @endforeach
                                    @endif
                                </select>

                            </div>
                        </div>


                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="input-label">{{ trans('admin/main.instructor') }}</label>

                                <select name="teacher_ids[]" multiple="multiple" data-search-option="just_teacher_role"
                                    class="form-control search-user-select2" data-placeholder="Select an instructor">

                                    @if(!empty($teachers) and $teachers->count() > 0)
                                    @foreach($teachers as $teacher)
                                    <option value="{{ $teacher->id }}" selected>{{ $teacher->full_name }}</option>
                                    @endforeach
                                    @endif
                                </select>
                            </div>
                        </div>


                        <div class="col-md-3">
                            <div class="form-group">
                                <label class="input-label">{{ trans('admin/main.student') }}</label>

                                <select name="student_ids[]" multiple="multiple" data-search-option="just_student_role"
                                    class="form-control search-user-select2" data-placeholder="Select a student">

                                    @if(!empty($students) and $students->count() > 0)
                                    @foreach($students as $student)
                                    <option value="{{ $student->id }}" selected>{{ $student->full_name }}</option>
                                    @endforeach
                                    @endif
                                </select>
                            </div>
                        </div>


                        <div class="col-md-3">
                            <div class="form-group mt-1">
                                <label class="input-label mb-4"> </label>
                                <input type="submit" class="text-center btn btn-primary w-100" value="{{ trans('admin/main.show_results') }}">
                            </div>
                        </div>
                    </div>

                </form>
            </div>
        </section>

        <div class="row">
            <div class="col-12 col-md-12">
                <div class="card">
                    <div class="card-header">
                        <a href="/admin/enrollments/export" class="btn btn-primary">{{ trans('admin/main.export_xls') }}</a>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped font-14">
                                <tbody>
                                    <tr>
                                        <th>#</th>
                                        <th class="text-left">{{ trans('admin/main.student') }}</th>
                                        <th class="text-left">{{ trans('admin/main.instructor') }}</th>
                                        <th class="text-left">{{ trans('admin/main.item') }}</th>
                                        <th>{{ trans('admin/main.type') }}</th>
                                        <th>{{ trans('admin/main.date') }}</th>
                                        <th>{{ trans('admin/main.status') }}</th>
                                        <th width="120">{{ trans('admin/main.actions') }}</th>
                                    </tr>

                                    @foreach($sales as $sale)
                                    <tr>
                                        <td>{{ $sale->id }}</td>

                                        <td class="text-left">
                                            {{ $sale->buyer->full_name }}
                                            <div class="text-primary text-small font-600-bold">ID : {{ $sale->buyer->id
                                                }}</div>
                                        </td>

                                        <td class="text-left">
                                            {{ $sale->seller->full_name }}
                                            <div class="text-primary text-small font-600-bold">ID : {{ $sale->seller->id
                                                }}</div>
                                        </td>

                                        <td class="text-left">
                                            <div class="media-body">
                                                <div>{{ $sale->webinar->title }}</div>
                                                <div class="text-primary text-small font-600-bold">ID :
                                                    {{$sale->webinar->id}}</div>
                                            </div>
                                        </td>

                                        <td>
                                            <span class="font-weight-bold">
                                                {{ trans('update.normal_purchased') }}
                                            </span>
                                        </td>

                                        <td>{{ vertaFormat($sale->created_at, '%d %B، %Y') }}</td>

                                        @if ($sale->access_to_purchased_item)
                                        <td>
                                            <span class="text-success">{{ trans('admin/main.success') }}</span>
                                        </td>
                                        @else
                                        <td>
                                            <span class="text-danger">{{ trans('update.access_blocked') }}</span>
                                        </td>
                                        @endif


                                        <td>
                                            <a href="/admin/financial/sales/{{ $sale->id }}/invoice" target="_blank"
                                                title="Invoice"><i class="fa fa-print" aria-hidden="true"></i></a>

                                            @if ($sale->access_to_purchased_item)
                                            <button class="btn-transparent text-primary trigger--fire-modal-1"
                                                data-confirm="Are you sure? | Do you want to continue?"
                                                data-confirm-href="/admin/enrollments/{{ $sale->id }}/block-access"
                                                data-confirm-text-yes="Yes" data-confirm-text-cancel="Cancel"
                                                data-toggle="tooltip" data-placement="top" title=""
                                                data-original-title="Block Access">
                                                <i class="fa fa-times-circle" aria-hidden="true"></i>
                                            </button>
                                            @else
                                            <button
                                                class="btn-transparent text-primary text-success ml-1 trigger--fire-modal-8"
                                                data-confirm="Are you sure? | Do you want to continue?"
                                                data-confirm-href="/admin/enrollments/{{ $sale->id }}/enable-access"
                                                data-confirm-text-yes="Yes" data-confirm-text-cancel="Cancel"
                                                data-toggle="tooltip" data-placement="top" title=""
                                                data-original-title="Enable student access">
                                                <i class="fa fa-check" aria-hidden="true"></i>
                                            </button>
                                            @endif

                                        </td>
                                    </tr>
                                    @endforeach


                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="card-footer text-center">
                        <nav>
                            {{ $sales->appends(request()->input())->links() }}
                        </nav>

                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

@endsection



@push('scripts_bottom')

<script src="/assets/admin/vendor/persian-date/persian-date.min.js"></script>

<script>
    jalaliDatepicker.startWatch({
        time: "true",
        autoReadOnlyInput: "dynamic",
        zIndex: "9999"
});
</script>

@endpush