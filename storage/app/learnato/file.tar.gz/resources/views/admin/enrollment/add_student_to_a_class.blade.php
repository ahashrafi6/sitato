@extends('admin.layouts.app')

@section('content')
<section class="section">
    <div class="section-header">
        <h1>{{ $pageTitle }}</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="/admin/">{{trans('admin/main.dashboard')}}</a>
            </div>
            <div class="breadcrumb-item">{{ $pageTitle}}</div>
        </div>
    </div>

    <div class="section-body" data-select2-id="select2-data-14-cjao">


        <div class="row" data-select2-id="select2-data-13-dnmj">
            <div class="col-12 col-md-12" data-select2-id="select2-data-12-tpn0">
                <div class="card" data-select2-id="select2-data-11-m2pl">

                    <div class="card-body" data-select2-id="select2-data-10-309v">
                        <div class="row" data-select2-id="select2-data-9-ndbs">
                            <div class="col-12 col-md-6" data-select2-id="select2-data-8-jlh1">
                                <form action="/admin/enrollments/store" method="Post"
                                    data-select2-id="select2-data-7-025d">
                                    {{ csrf_field() }}

                                    <div class="form-group" data-select2-id="select2-data-6-2d3m">
                                        <label class="input-label">{{ trans('admin/main.course') }}</label>

                                        <select name="webinar_id" class="form-control search-webinar-select2"
                                            data-select2-id="select2-data-3-7a92" data-placeholder="Search classes">
                                        </select>

                                    </div>

                                    <div class="form-group" data-select2-id="select2-data-18-lxxg">
                                        <label class="input-label d-block">{{ trans('admin/main.user') }}</label>
                    
                                        <select name="user_id" class="form-control search-user-select2"
                                        ata-select2-id="select2-data-1-t50q" data-placeholder="Search user">
                                        </select>

                                    </div>

                                    <div class=" mt-4">
                                        <button type="submit" class="btn btn-primary">Add</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>





@endsection

@push('scripts_bottom')

@endpush