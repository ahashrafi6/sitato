@extends('admin.layouts.app')

@push('libraries_top')
<link rel="stylesheet" href="/assets/default/vendors/sweetalert2/dist/sweetalert2.min.css">

<link rel="stylesheet" href="/assets/admin/vendor/persian-date/persian-date.min.css">
@endpush

@section('content')

<section class="section">
    <div class="section-header">
        <h1>{{ trans('update.users_do_not_have_access_to_the_content') }}</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a>{{ trans('admin/main.students') }}</a></div>
            <div class="breadcrumb-item"><a href="#">{{ trans('update.users_do_not_have_access_to_the_content') }}</a>
            </div>
        </div>
    </div>
</section>

<div class="section-body">
    <section class="card">
        <div class="card-body">
            <form method="get" class="mb-0">

                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="input-label">{{ trans('admin/main.search') }}</label>
                            <input name="full_name" type="text" class="form-control" value="">
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="input-label">{{ trans('admin/main.start_date') }}</label>
                            <div class="input-group">
                                <input data-jdp data-jdp-only-date class="form-control" name="from"
                                    value="{{ request()->get('from') }}">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="input-label">{{ trans('admin/main.end_date') }}</label>
                            <div class="input-group">
                                <input data-jdp data-jdp-only-date class="form-control" name="to"
                                    value="{{ request()->get('to') }}">
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group mt-1">
                            <label class="input-label mb-4"> </label>
                            <input type="submit" class="text-center btn btn-primary w-100"
                                value="{{ trans('public.show_results') }}">
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
</div>

<div class="card">
    <div class="card-header">
        <button type="button" id="addNewUserToNotaccess" class="btn btn-primary">{{ trans('admin/main.add_new')
            }}</button>
    </div>

    <div class="card-body">
        <div class="table-responsive text-center">
            <table class="table table-striped font-14">
                <tbody>
                    <tr>
                        <th>{{ trans('admin/main.id') }}</th>
                        <th class="text-left">{{ trans('admin/main.name') }}</th>
                        <th>{{ trans('panel.registration_date') }}</th>
                        <th>{{ trans('admin/main.status') }}</th>
                        <th>{{ trans('update.access_to_content') }}</th>
                        <th width="120">{{ trans('admin/main.actions') }}</th>
                    </tr>


                    @foreach($users as $user)
                    <tr>
                        <td>{{ $user->id }}</td>
                        <td class="text-left">
                            <div class="d-flex align-items-center">
                                <figure class="avatar mr-2">
                                    <img src="{{ $user->getAvatar() }}" alt="{{ $user->full_name }}">
                                </figure>
                                <div class="media-body ml-1">
                                    <div class="mt-0 mb-1 font-weight-bold">{{ $user->full_name }}</div>

                                    @if($user->mobile)
                                    <div class="text-primary text-small font-600-bold">{{ $user->mobile }}</div>
                                    @endif

                                    @if($user->email)
                                    <div class="text-primary text-small font-600-bold">{{ $user->email }}</div>
                                    @endif
                                </div>
                            </div>
                        </td>

                        <td>{{ vertaFormat($user->created_at, '%d %B، %Y') }}</td>

                        <td>
                            @if($user->ban and !empty($user->ban_end_at) and $user->ban_end_at > time())
                            <div class="mt-0 mb-1 font-weight-bold text-danger">{{ trans('admin/main.ban') }}</div>
                            <div class="text-small font-600-bold">Until {{ vertaFormat($user->ban_end_at, 'Y/m/j') }}
                            </div>
                            @else
                            <div
                                class="mt-0 mb-1 font-weight-bold {{ ($user->status == 'active') ? 'text-success' : 'text-warning' }}">
                                {{ trans('admin/main.'.$user->status) }}</div>
                            @endif
                        </td>

                        <td>
                            <div class="mt-0 mb-1 font-weight-bold text-danger">No</div>
                        </td>


                        <td class="text-center mb-2" width="120">
                            <a href="/admin/users/{{ $user->id }}/impersonate" target="_blank"
                                class="btn-transparent  text-primary" data-toggle="tooltip" data-placement="top"
                                title="" data-original-title="Login">
                                <i class="fa fa-user-shield"></i>
                            </a>

                            <a href="/admin/users/{{ $user->id }}/edit" class="btn-transparent  text-primary"
                                data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit">
                                <i class="fa fa-edit"></i>
                            </a>

                            <a href="/admin/users/not-access-to-content/{{ $user->id }}/active"
                                class="btn-transparent  text-primary" data-toggle="tooltip" data-placement="top"
                                title="" data-original-title="Active">
                                <i class="fa fa-arrow-up"></i>
                            </a>

                            <button class="btn-transparent text-primary trigger--fire-modal-1"
                                data-confirm="{{ trans('admin/main.delete_confirm_msg') }}"
                                data-confirm-href="/admin/users/{{ $user->id }}/delete"
                                data-confirm-text-yes="{{ trans('admin/main.yes') }}"
                                data-confirm-text-cancel="{{ trans('admin/main.cancel') }}" data-toggle="tooltip"
                                data-placement="top" title="" data-original-title="Delete">
                                <i class="fa fa-times" aria-hidden="true"></i>
                            </button>
                        </td>

                    </tr>
                    @endforeach

                </tbody>
            </table>
        </div>
    </div>

    <div class="card-footer text-center">

    </div>
</div>


<section class="card">
    <div class="card-body">
        <div class="section-title ml-0 mt-0 mb-3">
            <h5>{{ trans('admin/main.hints') }}</h5>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="media-body">
                    <div class="text-primary mt-0 mb-1 font-weight-bold">{{ trans('admin/main.students_hint_title_1') }}
                    </div>
                    <div class=" text-small font-600-bold">{{ trans('admin/main.students_hint_description_1') }}</div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="media-body">
                    <div class="text-primary mt-0 mb-1 font-weight-bold">{{ trans('admin/main.students_hint_title_2') }}
                    </div>
                    <div class=" text-small font-600-bold">{{ trans('admin/main.students_hint_description_2') }}</div>
                </div>
            </div>


            <div class="col-md-4">
                <div class="media-body">
                    <div class="text-primary mt-0 mb-1 font-weight-bold">{{ trans('admin/main.students_hint_title_3') }}
                    </div>
                    <div class="text-small font-600-bold">{{ trans('admin/main.students_hint_description_3') }}</div>
                </div>
            </div>


        </div>
    </div>
</section>

<div id="addUserToNotAccessModal" class="d-none">
    <h3 class="section-title after-line">{{ trans('update.users_do_not_have_access_to_the_content') }}</h3>
    <div class="mt-25">
        <form action="/admin/users/not-access-to-content/store" method="post">

            <div class="form-group">
                <label class="input-label d-block">{{ trans('admin/main.user') }}</label>
                <select name="user_id" class="form-control user-search" data-placeholder="{{ trans('public.search_user') }}">

                </select>
                    <div class="invalid-feedback"></div>
            </div>

            <div class="d-flex align-items-center justify-content-end mt-3">
                <button type="button" class="js-save-add-user-to-not-access btn btn-sm btn-primary">{{
                    trans('admin/main.save') }}</button>
                <button type="button" class="close-swl btn btn-sm btn-danger ml-2">{{ trans('admin/main.close')
                    }}</button>
            </div>
        </form>
    </div>
</div>



@endsection

@push('scripts_bottom')

<script src="/assets/default/vendors/sweetalert2/dist/sweetalert2.min.js"></script>
<script src="/assets/default/vendors/select2/select2.min.js"></script>

<script>
    var saveSuccessLang = '{{ trans('webinars.success_store') }}';
</script>

<script src="/assets/default/js/admin/not_access_to_content.min.js"></script>


<script src="/assets/admin/vendor/persian-date/persian-date.min.js"></script>

<script>
    jalaliDatepicker.startWatch({
        time: "true",
        autoReadOnlyInput: "dynamic",
        zIndex: "9999"
});
</script>

@endpush