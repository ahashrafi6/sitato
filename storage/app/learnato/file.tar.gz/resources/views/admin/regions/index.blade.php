@extends('admin.layouts.app')

@section('content')
<section class="section">
    <div class="section-header">
        <h1>{{ $pageTitle }}</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="/admin/">{{trans('admin/main.dashboard')}}</a>
            </div>
            <div class="breadcrumb-item">{{ $pageTitle}}</div>
        </div>
    </div>

    <div class="section-body">
        <section class="card">
            <div class="card-header">

                <div class="text-right">
                    <a href="/admin/regions/new?type={{ $type }}" class="btn btn-primary">{{ trans('admin/main.new') }}</a>
                </div>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped text-center font-14">
                        @if ($type == 'country')
                        <tbody>
                            <tr>
                                <th class="text-left">Title</th>
                                <th class="text-center">Provinces</th>
                                <th class="text-center">Instructor</th>
                                <th class="text-center">Date</th>
                                <th class="text-center">Actions</th>

                            </tr>
                            
                            @foreach ($regions as $item)
                            <tr>
                                <td>{{ $item->title }}</td>

                                <td>{{ $item->countryProvinces->count() }}</td>

                                <td>{{ $item->countryUsers->count() }}</td>

                                <td>{{ vertaFormat($item->created_at, 'Y M j | H:i') }}</td>

                                <td>
                                    <a href="/admin/regions/{{ $item->id }}/edit" class="btn-transparent text-primary mr-2">
                                        <i class="fa fa-edit"></i>
                                    </a>

                                    <button class="btn-transparent text-primary trigger--fire-modal-1"
                                        data-confirm="Are you sure? | Do you want to continue?"
                                        data-confirm-href="/admin/regions/{{ $item->id }}/delete" data-confirm-text-yes="Yes"
                                        data-confirm-text-cancel="Cancel" data-toggle="tooltip" data-placement="top"
                                        title="" data-original-title="Delete">
                                        <i class="fa fa-times" aria-hidden="true"></i>
                                    </button>
                                </td>
                            </tr>
                                
                            @endforeach
                        </tbody>
                        @endif
                        @if ($type == 'province')
                        <tbody>
                            <tr>
                                <th class="text-left">Title</th>
                                <th class="text-center">Country</th>
                                <th class="text-center">Cities</th>
                                <th class="text-center">Instructor</th>
                                <th class="text-center">Date</th>
                                <th class="text-center">Actions</th>

                            </tr>
                            
                            @foreach ($regions as $item)
                            <tr>
                                <td>{{ $item->title }}</td>
                                <td>{{ $item->country->title }}</td>

                                <td>{{ $item->provinceCities->count() }}</td>

                                <td>{{ $item->provinceUsers->count() }}</td>

                                <td>{{ vertaFormat($item->created_at, 'Y M j | H:i') }}</td>

                                <td>
                                    <a href="/admin/regions/{{$item->id }}/edit" class="btn-transparent text-primary mr-2">
                                        <i class="fa fa-edit"></i>
                                    </a>

                                    <button class="btn-transparent text-primary trigger--fire-modal-1"
                                        data-confirm="Are you sure? | Do you want to continue?"
                                        data-confirm-href="/admin/regions/{{ $item->id }}/delete" data-confirm-text-yes="Yes"
                                        data-confirm-text-cancel="Cancel" data-toggle="tooltip" data-placement="top"
                                        title="" data-original-title="Delete">
                                        <i class="fa fa-times" aria-hidden="true"></i>
                                    </button>
                                </td>
                            </tr>
                                
                            @endforeach
                        </tbody>
                        @endif
                        @if ($type == 'city')
                        <tbody>
                            <tr>
                                <th class="text-left">Title</th>
                                <th class="text-center">Country</th>
                                <th class="text-center">Province</th>
                                <th class="text-center">Instructor</th>
                                <th class="text-center">Date</th>
                                <th class="text-center">Actions</th>

                            </tr>
                            
                            @foreach ($regions as $item)
                            <tr>
                                <td>{{ $item->title }}</td>
                                <td>{{ $item->country->title }}</td>
                                <td>{{ $item->province->title }}</td>


                                <td>{{ $item->cityUsers->count() }}</td>

                                <td>{{ vertaFormat($item->created_at, 'Y M j | H:i') }}</td>

                                <td>
                                    <a href="/admin/regions/{{$item->id }}/edit" class="btn-transparent text-primary mr-2">
                                        <i class="fa fa-edit"></i>
                                    </a>

                                    <button class="btn-transparent text-primary trigger--fire-modal-1"
                                        data-confirm="Are you sure? | Do you want to continue?"
                                        data-confirm-href="/admin/regions/{{ $item->id }}/delete" data-confirm-text-yes="Yes"
                                        data-confirm-text-cancel="Cancel" data-toggle="tooltip" data-placement="top"
                                        title="" data-original-title="Delete">
                                        <i class="fa fa-times" aria-hidden="true"></i>
                                    </button>
                                </td>
                            </tr>
                                
                            @endforeach
                        </tbody>
                        @endif
                        @if ($type == 'district')
                        <tbody>
                            <tr>
                                <th class="text-left">Title</th>
                                <th class="text-center">Country</th>
                                <th class="text-center">Province</th>
                                <th class="text-center">City</th>
                                <th class="text-center">Instructor</th>
                                <th class="text-center">Date</th>
                                <th class="text-center">Actions</th>

                            </tr>
                            
                            @foreach ($regions as $item)
                            <tr>
                                <td>{{ $item->title }}</td>
                                <td>{{ $item->country->title }}</td>
                                <td>{{ $item->province->title }}</td>
                                <td>{{ $item->city->title }}</td>


                                <td>{{ $item->districtUsers->count() }}</td>

                                <td>{{ vertaFormat($item->created_at, 'Y M j | H:i') }}</td>

                                <td>
                                    <a href="/admin/regions/{{$item->id }}/edit" class="btn-transparent text-primary mr-2">
                                        <i class="fa fa-edit"></i>
                                    </a>

                                    <button class="btn-transparent text-primary trigger--fire-modal-1"
                                        data-confirm="Are you sure? | Do you want to continue?"
                                        data-confirm-href="/admin/regions/{{ $item->id }}/delete" data-confirm-text-yes="Yes"
                                        data-confirm-text-cancel="Cancel" data-toggle="tooltip" data-placement="top"
                                        title="" data-original-title="Delete">
                                        <i class="fa fa-times" aria-hidden="true"></i>
                                    </button>
                                </td>
                            </tr>
                                
                            @endforeach
                        </tbody>
                        @endif
                    </table>
                </div>
            </div>

            <div class="card-footer text-center">
                {{ $regions->appends(request()->input())->links() }}
            </div>
        </section>
    </div>
</section>





@endsection

@push('scripts_bottom')

@endpush