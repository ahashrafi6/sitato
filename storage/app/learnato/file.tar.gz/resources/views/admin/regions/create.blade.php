@extends('admin.layouts.app')

@push('styles_top')
    <link rel="stylesheet" href="/assets/vendors/leaflet/leaflet.css">
@endpush


@section('content')
<section class="section">
    <div class="section-header">
        <h1>{{ $pageTitle }}</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="/admin/">{{trans('admin/main.dashboard')}}</a>
            </div>
            <div class="breadcrumb-item">{{ $pageTitle}}</div>
        </div>
    </div>

    <div class="section-body">
        <section class="card">
            <div class="card-body">
        
                @if (request('type'))
                <form action="/admin/regions/store" method="post">
                    {{ csrf_field() }}
                    <input type="hidden" name="type" value="{{ request('type') }}">
                    <div class="row">
                        <div class="col-12 col-lg-6">

                          
                            @if( request('type') && request('type') != 'country')
                            <div id="countrySelectBox" class="form-group">
                                <label class="input-label">{{ trans('update.countries') }}</label>
                            
                                <select name="country_id" class="form-control search-region-select2 "
                                    data-type="country" data-placeholder="Search Countries">
                                    <option value="">انتخاب کنید</option>
                                    @foreach ($countries as $item)
                                 
                                        <option data-center="{{ $item->geo_center[0] . ',' .  $item->geo_center[1]}}" value="{{$item->id}}">{{ $item->title}}</option>
                                    @endforeach
                                </select>
                            </div>
                            @endif
                         

                            @if( request('type') && (request('type') == 'city' || request('type') == 'district'))
                            <div id="provinceSelectBox" class="form-group">
                                <label class="input-label">{{ trans('update.provinces') }}</label>

                                <select name="province_id" disabled="" class="form-control">
                                    <option value="">انتخاب کنید</option>

                                

                                </select>

                            </div>
                            @endif

                            @if(request('type') && request('type') == 'district')
                            <div id="citySelectBox" class="form-group">
                                <label class="input-label">{{ trans('update.city') }}</label>

                                <select name="city_id" disabled="" class="form-control ">
                                    <option value="">انتخاب کنید</option>

                            
                                 
                                </select>

                            </div>
                            @endif

                            <div class="form-group">
                                <label for="" class="input-label">{{ trans('admin/main.title') }}</label>
                                <input type="text" name="title" class="form-control " value="" placeholder="Title">
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-group">
                                <input type="hidden" id="LocationLatitude" name="latitude" value="">
                                <input type="hidden" id="LocationLongitude" name="longitude" value="">

                                <label class="input-label">{{ trans('update.select_location') }}</label>
                              {{--   <span class="d-block">{{ trans('update.select_location_hint') }}</span> --}}

                                <div class="region-map mt-2 leaflet-container leaflet-touch leaflet-retina leaflet-fade-anim leaflet-grab leaflet-touch-drag leaflet-touch-zoom"
                                    id="mapBox" data-latitude="" data-longitude="" data-zoom="5" tabindex="0">
                                    <img src="/assets/default/img/location.png" class="marker">
                                   
                                </div>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-success mt-4">{{ trans('admin/main.save') }}</button>
                </form>

                @else
                <form action="/admin/regions/{{ $region->id }}/update" method="post">
                    {{ csrf_field() }}
                    <input type="hidden" name="type" value="{{ !request('type') ? $region->type  : request('type') }}">
                    <div class="row">
                        <div class="col-12 col-lg-6">

                          
                            @if( $region->type != 'country')
                            <div id="countrySelectBox" class="form-group">
                                <label class="input-label">{{ trans('update.countries') }}</label>
                            
                                <select name="country_id" class="form-control search-region-select2 "
                                    data-type="country" data-placeholder="Search Countries">
                                    <option value="">انتخاب کنید</option>
                                    @foreach ($countries as $item)
                                 
                                        <option data-center="{{ $item->geo_center[0] . ',' .  $item->geo_center[1]}}" value="{{$item->id}}" {{ $region->country_id == $item->id ? 'selected' : '' }}>{{ $item->title}}</option>
                                    @endforeach
                                </select>
                            </div>
                            @endif
                         

                            @if($region->type == 'city' || $region->type == 'district')
                            <div id="provinceSelectBox" class="form-group">
                                <label class="input-label">{{ trans('update.provinces') }}</label>

                                <select name="province_id" class="form-control">
                                    <option value="">انتخاب کنید</option>

                                    @if(!request('type'))
                                    @foreach ($provinces as $item)
                                    <option value="{{$item->id}}" {{ $item->id == $region->province_id ? 'selected' : ''}}>{{ $item->title }}</option>
                                    @endforeach
                                     
                                    @endif

                                </select>

                            </div>
                            @endif

                            @if( $region->type == 'district')
                            <div id="citySelectBox" class="form-group">
                                <label class="input-label">{{ trans('update.city') }}</label>

                                <select name="city_id" class="form-control ">
                                    <option value="">انتخاب کنید</option>

                            
                                    @if(!request('type'))
                                    @foreach ($cities as $item)
                                    <option value="{{$item->id}}" {{ $item->id == $region->city_id ? 'selected' : ''}}>{{ $item->title }}</option>
                                    @endforeach
                                     
                                    @endif
                                </select>

                            </div>
                            @endif

                            <div class="form-group">
                                <label for="" class="input-label">{{ trans('admin/main.title') }}</label>
                                <input type="text" name="title" class="form-control " value="{{ !request('type') ? $region->title : '' }}" placeholder="Title">
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-group">
                                <input type="hidden" id="LocationLatitude" name="latitude" value="{{ !request('type') ? $region->geo_center[0] : '' }}">
                                <input type="hidden" id="LocationLongitude" name="longitude" value="{{ !request('type') ? $region->geo_center[1] : '' }}">

                                <label class="input-label">{{ trans('update.select_location') }}</label>
                              {{--   <span class="d-block">{{ trans('update.select_location_hint') }}</span> --}}

                                <div class="region-map mt-2 leaflet-container leaflet-touch leaflet-retina leaflet-fade-anim leaflet-grab leaflet-touch-drag leaflet-touch-zoom"
                                    id="mapBox" data-latitude="{{ !request('type') ? $region->geo_center[0] : '' }}" data-longitude="{{ !request('type') ? $region->geo_center[1] : '' }}" data-zoom="5" tabindex="0">
                                    <img src="/assets/default/img/location.png" class="marker">
                                   
                                </div>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-success mt-4">{{ trans('admin/main.save') }}</button>
                </form>
                @endif

            </div>
        </section>
    </div>
</section>

@endsection


@push('scripts_bottom')
    <script src="/assets/vendors/leaflet/leaflet.min.js"></script>

      <script>
        var selectProvinceLang = 'Select Province';
        var selectCityLang = 'Select City';
    </script>
    <script src="/assets/default/js/admin/regions_create.min.js"></script>

@endpush
