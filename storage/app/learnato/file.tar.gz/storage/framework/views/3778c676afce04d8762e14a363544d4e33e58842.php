<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
    <defs>
        <clipPath id="clip-path">
            <path id="Rectangle_204" fill="#1f3b64" stroke="#707070" d="M0 0H24V24H0z" data-name="Rectangle 204" transform="translate(25 410)"/>
        </clipPath>
    </defs>
    <g id="Mask_Group_20" clip-path="url(#clip-path)" data-name="Mask Group 20" transform="translate(-25 -410)">
        <g id="money_1_" data-name="money (1)" transform="translate(25 410)">
            <path id="Path_168" d="M21.176 18.446v-3.622a9.191 9.191 0 0 0-6.061-8.631 2.112 2.112 0 0 0-.577-3.043A3.514 3.514 0 0 0 15.527.7a.7.7 0 0 0-.7-.7H9.176a.7.7 0 0 0-.7.7 3.514 3.514 0 0 0 .99 2.447 2.112 2.112 0 0 0-.577 3.043 9.191 9.191 0 0 0-6.061 8.631v3.622A2.821 2.821 0 0 0 3.527 24h16.946a2.821 2.821 0 0 0 .7-5.554zM14 1.406a2.121 2.121 0 0 1-4 0zm-3.412 4.242a.709.709 0 0 1 0-1.418h2.824a.709.709 0 0 1 0 1.418zm9.885 16.945H3.527a1.415 1.415 0 1 1 0-2.83.7.7 0 0 0 .7-.7v-4.239a7.77 7.77 0 1 1 15.539 0v4.236a.7.7 0 0 0 .7.7 1.415 1.415 0 1 1 0 2.83z" class="cls-3" data-name="Path 168"/>
            <path id="Path_169" d="M12 12.7h1.412a.7.7 0 0 0 0-1.406H12.7v-.709a.7.7 0 0 0-1.406 0v.83a2.115 2.115 0 0 0 .7 4.11.709.709 0 0 1 0 1.418h-1.406a.7.7 0 0 0 0 1.406h.712v.709a.7.7 0 0 0 1.406 0v-.83a2.115 2.115 0 0 0-.7-4.11A.709.709 0 0 1 12 12.7z" class="cls-3" data-name="Path 169"/>
        </g>
    </g>
</svg>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/rocket/resources/views/web/default/panel/includes/sidebar_icons/financial.blade.php ENDPATH**/ ?>