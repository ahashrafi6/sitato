<svg xmlns="http://www.w3.org/2000/svg" width="23.999" height="23.999" viewBox="0 0 23.999 23.999">
    <g id="Group_1263" transform="translate(-161.102 -869.102)">
        <g id="power-button" transform="translate(161.102 869.102)">
            <path id="Path_1541" d="M20.473 3.526a11.984 11.984 0 1 0 0 16.947 11.945 11.945 0 0 0 0-16.947zM12 22.591A10.591 10.591 0 1 1 22.591 12 10.6 10.6 0 0 1 12 22.591z" class="cls-1"/>
            <path id="Path_1542" d="M153.7 168.953a.7.7 0 0 0-.93 1.047 3.8 3.8 0 1 1-5.016-.019.7.7 0 1 0-.925-1.058 5.2 5.2 0 1 0 6.875.025z" class="cls-1" transform="translate(-138.252 -160.845)"/>
            <path id="Path_1543" d="M241.753 126.205a.7.7 0 0 0 .7-.7v-3.749a.7.7 0 1 0-1.406 0v3.744a.7.7 0 0 0 .706.705z" class="cls-1" transform="translate(-229.754 -115.378)"/>
        </g>
    </g>
</svg>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/rocket/resources/views/web/default/panel/includes/sidebar_icons/logout.blade.php ENDPATH**/ ?>