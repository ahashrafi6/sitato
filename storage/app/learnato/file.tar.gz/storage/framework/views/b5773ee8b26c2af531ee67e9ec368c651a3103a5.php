<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1><?php echo e($pageTitle); ?></h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="/admin/"><?php echo e(trans('admin/main.dashboard')); ?></a>
            </div>
            <div class="breadcrumb-item"><?php echo e($pageTitle); ?></div>
        </div>
    </div>

    <div class="section-body">
        <section class="card">
            <div class="card-header">

                <div class="text-right">
                    <a href="/admin/regions/new?type=<?php echo e($type); ?>" class="btn btn-primary"><?php echo e(trans('admin/main.new')); ?></a>
                </div>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped text-center font-14">
                        <?php if($type == 'country'): ?>
                        <tbody>
                            <tr>
                                <th class="text-left">Title</th>
                                <th class="text-center">Provinces</th>
                                <th class="text-center">Instructor</th>
                                <th class="text-center">Date</th>
                                <th class="text-center">Actions</th>

                            </tr>
                            
                            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->title); ?></td>

                                <td><?php echo e($item->countryProvinces->count()); ?></td>

                                <td><?php echo e($item->countryUsers->count()); ?></td>

                                <td><?php echo e(vertaFormat($item->created_at, 'Y M j | H:i')); ?></td>

                                <td>
                                    <a href="/admin/regions/<?php echo e($item->id); ?>/edit" class="btn-transparent text-primary mr-2">
                                        <i class="fa fa-edit"></i>
                                    </a>

                                    <button class="btn-transparent text-primary trigger--fire-modal-1"
                                        data-confirm="Are you sure? | Do you want to continue?"
                                        data-confirm-href="/admin/regions/<?php echo e($item->id); ?>/delete" data-confirm-text-yes="Yes"
                                        data-confirm-text-cancel="Cancel" data-toggle="tooltip" data-placement="top"
                                        title="" data-original-title="Delete">
                                        <i class="fa fa-times" aria-hidden="true"></i>
                                    </button>
                                </td>
                            </tr>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <?php endif; ?>
                        <?php if($type == 'province'): ?>
                        <tbody>
                            <tr>
                                <th class="text-left">Title</th>
                                <th class="text-center">Country</th>
                                <th class="text-center">Cities</th>
                                <th class="text-center">Instructor</th>
                                <th class="text-center">Date</th>
                                <th class="text-center">Actions</th>

                            </tr>
                            
                            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->country->title); ?></td>

                                <td><?php echo e($item->provinceCities->count()); ?></td>

                                <td><?php echo e($item->provinceUsers->count()); ?></td>

                                <td><?php echo e(vertaFormat($item->created_at, 'Y M j | H:i')); ?></td>

                                <td>
                                    <a href="/admin/regions/<?php echo e($item->id); ?>/edit" class="btn-transparent text-primary mr-2">
                                        <i class="fa fa-edit"></i>
                                    </a>

                                    <button class="btn-transparent text-primary trigger--fire-modal-1"
                                        data-confirm="Are you sure? | Do you want to continue?"
                                        data-confirm-href="/admin/regions/<?php echo e($item->id); ?>/delete" data-confirm-text-yes="Yes"
                                        data-confirm-text-cancel="Cancel" data-toggle="tooltip" data-placement="top"
                                        title="" data-original-title="Delete">
                                        <i class="fa fa-times" aria-hidden="true"></i>
                                    </button>
                                </td>
                            </tr>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <?php endif; ?>
                        <?php if($type == 'city'): ?>
                        <tbody>
                            <tr>
                                <th class="text-left">Title</th>
                                <th class="text-center">Country</th>
                                <th class="text-center">Province</th>
                                <th class="text-center">Instructor</th>
                                <th class="text-center">Date</th>
                                <th class="text-center">Actions</th>

                            </tr>
                            
                            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->country->title); ?></td>
                                <td><?php echo e($item->province->title); ?></td>


                                <td><?php echo e($item->cityUsers->count()); ?></td>

                                <td><?php echo e(vertaFormat($item->created_at, 'Y M j | H:i')); ?></td>

                                <td>
                                    <a href="/admin/regions/<?php echo e($item->id); ?>/edit" class="btn-transparent text-primary mr-2">
                                        <i class="fa fa-edit"></i>
                                    </a>

                                    <button class="btn-transparent text-primary trigger--fire-modal-1"
                                        data-confirm="Are you sure? | Do you want to continue?"
                                        data-confirm-href="/admin/regions/<?php echo e($item->id); ?>/delete" data-confirm-text-yes="Yes"
                                        data-confirm-text-cancel="Cancel" data-toggle="tooltip" data-placement="top"
                                        title="" data-original-title="Delete">
                                        <i class="fa fa-times" aria-hidden="true"></i>
                                    </button>
                                </td>
                            </tr>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <?php endif; ?>
                        <?php if($type == 'district'): ?>
                        <tbody>
                            <tr>
                                <th class="text-left">Title</th>
                                <th class="text-center">Country</th>
                                <th class="text-center">Province</th>
                                <th class="text-center">City</th>
                                <th class="text-center">Instructor</th>
                                <th class="text-center">Date</th>
                                <th class="text-center">Actions</th>

                            </tr>
                            
                            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->country->title); ?></td>
                                <td><?php echo e($item->province->title); ?></td>
                                <td><?php echo e($item->city->title); ?></td>


                                <td><?php echo e($item->districtUsers->count()); ?></td>

                                <td><?php echo e(vertaFormat($item->created_at, 'Y M j | H:i')); ?></td>

                                <td>
                                    <a href="/admin/regions/<?php echo e($item->id); ?>/edit" class="btn-transparent text-primary mr-2">
                                        <i class="fa fa-edit"></i>
                                    </a>

                                    <button class="btn-transparent text-primary trigger--fire-modal-1"
                                        data-confirm="Are you sure? | Do you want to continue?"
                                        data-confirm-href="/admin/regions/<?php echo e($item->id); ?>/delete" data-confirm-text-yes="Yes"
                                        data-confirm-text-cancel="Cancel" data-toggle="tooltip" data-placement="top"
                                        title="" data-original-title="Delete">
                                        <i class="fa fa-times" aria-hidden="true"></i>
                                    </button>
                                </td>
                            </tr>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <?php endif; ?>
                    </table>
                </div>
            </div>

            <div class="card-footer text-center">
                <?php echo e($regions->appends(request()->input())->links()); ?>

            </div>
        </section>
    </div>
</section>





<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts_bottom'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/rocket/resources/views/admin/regions/index.blade.php ENDPATH**/ ?>