<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
    <g id="Mask_Group_21" clip-path="url(#clip-path)" data-name="Mask Group 21" transform="translate(-25 -410)">
        <g id="online-class_1_" data-name="online-class (1)" transform="translate(25 410)">
            <path id="Path_170" d="M21.422 0H2.578A2.581 2.581 0 0 0 0 2.578v18.844A2.581 2.581 0 0 0 2.578 24h18.844A2.581 2.581 0 0 0 24 21.422V2.578A2.581 2.581 0 0 0 21.422 0zM1.406 2.578a1.173 1.173 0 0 1 1.172-1.172h18.844a1.173 1.173 0 0 1 1.172 1.172v13.453H1.406zm21.188 18.844a1.173 1.173 0 0 1-1.172 1.172H2.578a1.173 1.173 0 0 1-1.172-1.172v-3.984h21.188z" class="cls-3" data-name="Path 170"/>
            <path id="Path_171" d="M3.563 20.719h9.609v.234a.7.7 0 0 0 1.406 0v-.234h5.859a.7.7 0 0 0 0-1.406h-5.859v-.234a.7.7 0 0 0-1.406 0v.234H3.563a.7.7 0 0 0 0 1.406z" class="cls-3" data-name="Path 171"/>
            <path id="Path_172" d="M20.167 6.122L12.2 3.779a.7.7 0 0 0-.4 0L3.833 6.122a.7.7 0 0 0 0 1.349l2.777.817v3.665a.7.7 0 0 0 .7.7h9.375a.7.7 0 0 0 .7-.7V8.288l1.875-.551v3.279a.7.7 0 0 0 1.406 0V6.8a.7.7 0 0 0-.499-.678zm-4.183 5.128H8.016V8.7L11.8 9.815a.7.7 0 0 0 .4 0L15.984 8.7zM12 8.408L6.523 6.8 12 5.186 17.477 6.8z" class="cls-3" data-name="Path 172"/>
        </g>
    </g>
</svg>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/rocket/resources/views/web/default/panel/includes/sidebar_icons/requests.blade.php ENDPATH**/ ?>