<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
    <defs>
        <clipPath id="clip-path">
            <path id="Rectangle_204" fill="#1f3b64" stroke="#707070" d="M0 0H24V24H0z" data-name="Rectangle 204" transform="translate(25 410)"/>
        </clipPath>
    </defs>
    <g id="Mask_Group_19" clip-path="url(#clip-path)" data-name="Mask Group 19" transform="translate(-25 -410)">
        <g id="reward" transform="translate(25 410)">
            <g id="Group_183" data-name="Group 183">
                <g id="Group_182" data-name="Group 182">
                    <path id="Path_163" d="M16.423 5.789a7.668 7.668 0 0 0-1.478-.824l-.59 1.406a6.165 6.165 0 0 1 1.181.659z" class="cls-3" data-name="Path 163"/>
                    <path id="Path_164" d="M18.665 8.291a7.619 7.619 0 0 0-.982-1.373l-1.136 1.018a6.177 6.177 0 0 1 .786 1.1z" class="cls-3" data-name="Path 164"/>
                    <path id="Path_165" d="M17.855 10.28a6.092 6.092 0 1 1-4.794-4.29l.263-1.5A7.81 7.81 0 0 0 12 4.374a7.618 7.618 0 1 0 7.321 5.479z" class="cls-3" data-name="Path 165"/>
                    <path id="Path_166" d="M24 12l-1.954-2.692L22.393 6l-3.038-1.355L18 1.607l-3.308.347L12 0 9.308 1.954 6 1.607 4.645 4.645 1.607 6l.347 3.308L0 12l1.954 2.692L1.607 18l3.038 1.354L6 22.393l3.308-.347L12 24l2.692-1.954 3.308.347 1.354-3.038L22.393 18l-.347-3.308zm-5.8 6.2l-1.145 2.56-2.785-.3L12 22.116l-2.27-1.651-2.788.292L5.8 18.2l-2.563-1.148.3-2.782L1.884 12l1.651-2.27-.3-2.788L5.8 5.8l1.145-2.563 2.788.292L12 1.884l2.27 1.651 2.788-.292L18.2 5.8l2.562 1.144-.3 2.782L22.116 12l-1.651 2.27.292 2.788z" class="cls-3" data-name="Path 166"/>
                    <path id="Path_167" d="M8.726 11.461l-1.078 1.078 2.827 2.827 5.115-5.115-1.079-1.078-4.036 4.037z" class="cls-3" data-name="Path 167"/>
                </g>
            </g>
        </g>
    </g>
</svg>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/rocket/resources/views/web/default/panel/includes/sidebar_icons/certificate.blade.php ENDPATH**/ ?>