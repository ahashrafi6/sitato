<?php $__env->startPush('styles_top'); ?>
    <link rel="stylesheet" href="/assets/vendors/leaflet/leaflet.css">
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1><?php echo e($pageTitle); ?></h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="/admin/"><?php echo e(trans('admin/main.dashboard')); ?></a>
            </div>
            <div class="breadcrumb-item"><?php echo e($pageTitle); ?></div>
        </div>
    </div>

    <div class="section-body">
        <section class="card">
            <div class="card-body">
        
                <?php if(request('type')): ?>
                <form action="/admin/regions/store" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="type" value="<?php echo e(request('type')); ?>">
                    <div class="row">
                        <div class="col-12 col-lg-6">

                          
                            <?php if( request('type') && request('type') != 'country'): ?>
                            <div id="countrySelectBox" class="form-group">
                                <label class="input-label"><?php echo e(trans('update.countries')); ?></label>
                            
                                <select name="country_id" class="form-control search-region-select2 "
                                    data-type="country" data-placeholder="Search Countries">
                                    <option value="">انتخاب کنید</option>
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 
                                        <option data-center="<?php echo e($item->geo_center[0] . ',' .  $item->geo_center[1]); ?>" value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php endif; ?>
                         

                            <?php if( request('type') && (request('type') == 'city' || request('type') == 'district')): ?>
                            <div id="provinceSelectBox" class="form-group">
                                <label class="input-label"><?php echo e(trans('update.provinces')); ?></label>

                                <select name="province_id" disabled="" class="form-control">
                                    <option value="">انتخاب کنید</option>

                                

                                </select>

                            </div>
                            <?php endif; ?>

                            <?php if(request('type') && request('type') == 'district'): ?>
                            <div id="citySelectBox" class="form-group">
                                <label class="input-label"><?php echo e(trans('update.city')); ?></label>

                                <select name="city_id" disabled="" class="form-control ">
                                    <option value="">انتخاب کنید</option>

                            
                                 
                                </select>

                            </div>
                            <?php endif; ?>

                            <div class="form-group">
                                <label for="" class="input-label"><?php echo e(trans('admin/main.title')); ?></label>
                                <input type="text" name="title" class="form-control " value="" placeholder="Title">
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-group">
                                <input type="hidden" id="LocationLatitude" name="latitude" value="">
                                <input type="hidden" id="LocationLongitude" name="longitude" value="">

                                <label class="input-label"><?php echo e(trans('update.select_location')); ?></label>
                              

                                <div class="region-map mt-2 leaflet-container leaflet-touch leaflet-retina leaflet-fade-anim leaflet-grab leaflet-touch-drag leaflet-touch-zoom"
                                    id="mapBox" data-latitude="" data-longitude="" data-zoom="5" tabindex="0">
                                    <img src="/assets/default/img/location.png" class="marker">
                                   
                                </div>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-success mt-4"><?php echo e(trans('admin/main.save')); ?></button>
                </form>

                <?php else: ?>
                <form action="/admin/regions/<?php echo e($region->id); ?>/update" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="type" value="<?php echo e(!request('type') ? $region->type  : request('type')); ?>">
                    <div class="row">
                        <div class="col-12 col-lg-6">

                          
                            <?php if( $region->type != 'country'): ?>
                            <div id="countrySelectBox" class="form-group">
                                <label class="input-label"><?php echo e(trans('update.countries')); ?></label>
                            
                                <select name="country_id" class="form-control search-region-select2 "
                                    data-type="country" data-placeholder="Search Countries">
                                    <option value="">انتخاب کنید</option>
                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 
                                        <option data-center="<?php echo e($item->geo_center[0] . ',' .  $item->geo_center[1]); ?>" value="<?php echo e($item->id); ?>" <?php echo e($region->country_id == $item->id ? 'selected' : ''); ?>><?php echo e($item->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php endif; ?>
                         

                            <?php if($region->type == 'city' || $region->type == 'district'): ?>
                            <div id="provinceSelectBox" class="form-group">
                                <label class="input-label"><?php echo e(trans('update.provinces')); ?></label>

                                <select name="province_id" class="form-control">
                                    <option value="">انتخاب کنید</option>

                                    <?php if(!request('type')): ?>
                                    <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $region->province_id ? 'selected' : ''); ?>><?php echo e($item->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     
                                    <?php endif; ?>

                                </select>

                            </div>
                            <?php endif; ?>

                            <?php if( $region->type == 'district'): ?>
                            <div id="citySelectBox" class="form-group">
                                <label class="input-label"><?php echo e(trans('update.city')); ?></label>

                                <select name="city_id" class="form-control ">
                                    <option value="">انتخاب کنید</option>

                            
                                    <?php if(!request('type')): ?>
                                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $region->city_id ? 'selected' : ''); ?>><?php echo e($item->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     
                                    <?php endif; ?>
                                </select>

                            </div>
                            <?php endif; ?>

                            <div class="form-group">
                                <label for="" class="input-label"><?php echo e(trans('admin/main.title')); ?></label>
                                <input type="text" name="title" class="form-control " value="<?php echo e(!request('type') ? $region->title : ''); ?>" placeholder="Title">
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-group">
                                <input type="hidden" id="LocationLatitude" name="latitude" value="<?php echo e(!request('type') ? $region->geo_center[0] : ''); ?>">
                                <input type="hidden" id="LocationLongitude" name="longitude" value="<?php echo e(!request('type') ? $region->geo_center[1] : ''); ?>">

                                <label class="input-label"><?php echo e(trans('update.select_location')); ?></label>
                              

                                <div class="region-map mt-2 leaflet-container leaflet-touch leaflet-retina leaflet-fade-anim leaflet-grab leaflet-touch-drag leaflet-touch-zoom"
                                    id="mapBox" data-latitude="<?php echo e(!request('type') ? $region->geo_center[0] : ''); ?>" data-longitude="<?php echo e(!request('type') ? $region->geo_center[1] : ''); ?>" data-zoom="5" tabindex="0">
                                    <img src="/assets/default/img/location.png" class="marker">
                                   
                                </div>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-success mt-4"><?php echo e(trans('admin/main.save')); ?></button>
                </form>
                <?php endif; ?>

            </div>
        </section>
    </div>
</section>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts_bottom'); ?>
    <script src="/assets/vendors/leaflet/leaflet.min.js"></script>

      <script>
        var selectProvinceLang = 'Select Province';
        var selectCityLang = 'Select City';
    </script>
    <script src="/assets/default/js/admin/regions_create.min.js"></script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/rocket/resources/views/admin/regions/create.blade.php ENDPATH**/ ?>